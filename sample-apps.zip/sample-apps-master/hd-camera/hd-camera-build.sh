g++ -o hd-camera.bin hd-camera.cpp -lopencv_core -lopencv_imgproc -lopencv_highgui
